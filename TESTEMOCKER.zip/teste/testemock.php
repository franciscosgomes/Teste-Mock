<?php
// tests/BalanceteSIPIAServiceTest.php

use PHPUnit\Framework\TestCase;

// Inclui o arquivo da classe que queremos testar
require_once __DIR__ . '/../src/BalanceteSIPIAService.php';

/**
 * Classe de Teste: BalanceteSIPIAServiceTest
 * Estende o TestCase do PHPUnit para rodar os testes.
 */
class BalanceteSIPIAServiceTest extends TestCase
{
    /**
     * Teste 1: Verifica o fluxo completo de sucesso.
     */
    public function testEnviarBalanceteComSucesso()
    {
        // 1. MOCKS: Cria substitutos para o Storage e Repository
        $mockStorage = $this->createMock(stdClass::class);
        $mockRepository = $this->createMock(stdClass::class);

        // CONFIGURAÇÃO DO MOCK STORAGE: Define que 'upload' deve retornar um caminho
        $mockStorage->method('upload')
                    ->willReturn('/uploads/balancetes/janeiro2025.pdf');

        // EXPECTATIVA NO MOCK REPOSITORY: Espera que o método 'salvar' seja chamado EXATAMENTE UMA VEZ
        $mockRepository->expects($this->once())
                        ->method('salvar');

        // 2. INSTANCIAÇÃO: Cria o serviço injetando os mocks (objetos falsos)
        $service = new BalanceteSIPIAService($mockStorage, $mockRepository);

        $arquivo = ['name' => 'janeiro2025.pdf', 'tmp_name' => '/tmp/php123'];

        // 3. ASSERÇÃO: Roda a função e verifica se o retorno está correto
        $resultado = $service->enviarBalancete(1, $arquivo);
        $this->assertEquals("Balancete enviado com sucesso!", $resultado);
    }

    /**
     * Teste 2: Verifica se uma exceção é lançada quando não há arquivo.
     */
    public function testEnviarBalanceteSemArquivoLancaExcecao()
    {
        $mockStorage = $this->createMock(stdClass::class);
        $mockRepository = $this->createMock(stdClass::class);

        $service = new BalanceteSIPIAService($mockStorage, $mockRepository);

        // EXPECTATIVA DE EXCEÇÃO: Espera que a próxima linha lance uma Exception
        $this->expectException(Exception::class);
        
        // Chamada com arquivo vazio
        $service->enviarBalancete(1, ['name' => '']);
        // O teste passa se a exceção for lançada
    }
}