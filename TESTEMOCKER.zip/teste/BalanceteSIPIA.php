<?php
// src/BalanceteSIPIAService.php

/**
 * Classe de Serviço: BalanceteSIPIAService.
 * Responsável por orquestrar o envio de Balancetes (validação, upload e registro).
 */
class BalanceteSIPIAService
{
    private $storage; // Dependência para Armazenamento (ex: S3, disco)
    private $repository; // Dependência para Persistência de Dados (ex: Banco de Dados)

    // Construtor: Injeta as dependências de Storage e Repository
    public function __construct($storage, $repository)
    {
        $this->storage = $storage;
        $this->repository = $repository;
    }

    /**
     * Processa o envio do Balancete.
     */
    public function enviarBalancete($prefeituraId, $arquivo)
    {
        // 1. Validação: Verifica se há um arquivo enviado
        if (empty($arquivo['name'])) {
            throw new Exception("Nenhum arquivo enviado.");
        }

        // 2. Armazenamento: Chama o upload (Simulado)
        $caminho = $this->storage->upload($arquivo);

        // 3. Persistência: Registra o envio no "banco" (Simulado)
        $this->repository->salvar([
            'prefeitura_id' => $prefeituraId,
            'arquivo' => $caminho,
            'data_envio' => date('Y-m-d H:i:s')
        ]);

        return "Balancete enviado com sucesso!";
    }
}